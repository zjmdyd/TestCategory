var app = getApp()
var temp = []
Page({
    data: {
        motto: 'Hello World',
        userInfo: {},
        isopen: false,
        disabled: false,
        connected: false
    },
    switchChange: function () {
        var that = this
        that.setData({
            isopen: !that.data.isopen,
            errmsg: ""
        })
        if (that.data.isopen) {
            wx.openBluetoothAdapter({
                success: function (res) {
                    console.log(res)
                    that.setData({
                        errmsg: "功能已启用"
                    })
                    wx.onBluetoothAdapterStateChange(function (res) {
                        console.log("蓝牙适配器状态变化", res)
                        that.setData({
                            actioninfo: res.available ? "蓝牙适配器可用" : "蓝牙适配器不可用",
                            searchingstatus: res.discovering ? "正在搜索" : "搜索可用"
                        })
                    })
                    wx.onBluetoothDeviceFound(function (res) {
                        // console.log('发现新蓝牙设备')
                        // console.log(JSON.stringify(res))
                        // let devices = res.devices
                        // for (let i = 0; i < devices.length; i++) {
                        //     //if(devices[i].name.indexOf("A-")>-1)
                        //     //{
                        //         console.log('2发现新蓝牙设备')
                        //         temp.push(devices[i])
                        //         console.log('2设备deviceId:' + devices[i].deviceId)
                        //         console.log('2设备name:' + devices[i].name)
                        //         console.log('2设备info:' + JSON.stringify(devices[i]))
                                
                        //         that.setData({
                        //         devices: temp
                        //         })
                        //     //}
                        // }
                            // if(devices[0].name.indexOf("A-")>-1)
                            // {
                            //     console.log('2发现新蓝牙设备')
                            //     temp.push(devices[0])
                            //     console.log('2设备deviceId:' + devices[0].deviceId)
                            //     console.log('2设备name:' + devices[0].name)
                            //     console.log('2设备info:' + JSON.stringify(devices[0]))
                                
                            //     that.setData({
                            //     devices: temp
                            //     })
                            // }
                        })
                },
                fail: function (res) {
                    console.log(res)
                    that.setData({
                        errmsg: "请检查手机蓝牙是否打开"
                    })
                }
            })
        } else {
            wx.closeBluetoothAdapter({
                success: function (res) {
                    console.log(res)
                    that.setData({
                        errmsg: "功能已关闭"
                    })
                },
                fail: function (res) {
                    console.log(res)
                    that.setData({
                        errmsg: "请检查手机蓝牙是否打开"
                    })
                }
            })
        }
        console.log('bluetooth is open :' + that.data.isopen)
    },
    searchbluetooth: function () {
        var that = this
        wx.startBluetoothDevicesDiscovery({
            success: function (res) {
                console.log("开始搜索附近蓝牙设备")
                console.log(res)
            }
        })
    },
    connectTO: function (e) {
        var that = this
        console.log(e)
        wx.createBLEConnection({
            deviceId: e.currentTarget.id,
            //deviceId: "98:D3:32:30:B0:4E",
            success: function (res) {
                console.log("连接设备成功")
                console.log(res)
                that.setData({
                    connected: true,
                    connectedDeviceId: e.currentTarget.id
                })
            },
            fail: function (res) {
                console.log("连接设备失败")
                console.log(res)
                that.setData({
                    connected: false
                })
            }
        })
        wx.onBLECharacteristicValueChange(function (res) {
                                    console.log('characteristic value comed:',JSON.stringify(res))
                                    let buffer = res.value
                                    console.log("接收字节:"+uint8Array2Str(buffer))

        })
        wx.stopBluetoothDevicesDiscovery(function () {

        })
    },
    showbluetooth: function () {
        var that = this
        wx.getBluetoothDevices({
            success: function (res) {
                console.log('发现新蓝牙设备')
                console.log(JSON.stringify(res))
                let devices = res.devices
                for (let i = 0; i < devices.length; i++) {
                    if(devices[i].name.indexOf("A-")>-1){
                        console.log('2发现新蓝牙设备')
                        temp.push(devices[i])
                        console.log('2设备deviceId:' + devices[i].deviceId)
                        console.log('2设备name:' + devices[i].name)
                        console.log('2设备info:' + JSON.stringify(devices[i]))
                        console.log("2设备advertisData:"+uint8Array2Str(devices[i].advertisData))
                        that.setData({
                        devices: temp
                        })
                    }
                }
            }
        })
    },
    checkbluetooth: function () {
        var that = this
        wx.getBluetoothAdapterState({
            success: function (res) {
                console.log(res)
                that.setData({
                    actioninfo: res.available ? "蓝牙适配器可用" : "蓝牙适配器不可用",
                    searchingstatus: res.discovering ? "正在搜索" : "搜索可用"
                })
            },
            fail: function (res) {
                console.log(res)
                that.setData({
                    errmsg: "获取蓝牙适配器信息失败"
                })
            }
        })
    },
    stopsearch: function () {
        wx.stopBluetoothDevicesDiscovery({
            success: function (res) {
                console.log("停止蓝牙搜索")
                console.log(res)
            }
        })
    },
    sendtoequ: function (e) {
        var that = this
        console.log(this.data.services)
        console.log("发送消息到:deviceId" + that.data.connectedDeviceId);
        console.log("serviceId:" + that.data.writeServiceId);
        console.log("characteristicId:" + that.data.writeCharacteristicId);
        console.log("发送消息:" + this.data.inputValue);
        let arr = str2Bytes(this.data.inputValue);
        let buffer = new ArrayBuffer(arr.length)
        let dataView = new DataView(buffer)
        for (let i = 0; i < arr.length; i++) {
            dataView.setUint8(i, arr[i])
        }
        // let dataView = new DataView(buffer)
        // dataView.setUint8(0, 6)

        wx.writeBLECharacteristicValue({
            // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
            deviceId: that.data.connectedDeviceId,
            // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
            serviceId: that.data.writeServiceId,
            // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
            characteristicId: that.data.writeCharacteristicId,
            // 这里的value是ArrayBuffer类型
            value: buffer,
            success: function (res) {
                console.log(res)
                console.log('writeBLECharacteristicValue success', res.errMsg)
            }
        })
    },
    inputTextchange: function (e) {
        console.log("数据变化")
        console.log(e)
        this.setData({
            inputValue: e.detail.value
        })
    },
    getAllservice: function (e) {
        var that = this
        console.log(this.data.connectedDeviceId);
        wx.getBLEDeviceServices({
            // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取

            deviceId: this.data.connectedDeviceId,
            complete: function (res) {
                console.log('device services:', JSON.stringify(res))
                that.setData({
                    services: res.services
                })
            }
        })
    },
    linkto: function (e) {
        var that = this
        wx.getBLEDeviceCharacteristics({
            // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
            deviceId: that.data.connectedDeviceId,
            // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
            serviceId: e.currentTarget.id,
            success: function (res) {
                console.log('device getBLEDeviceCharacteristics:', res.characteristics)
                console.log(res)
                for (let i = 0; i < res.characteristics.length; i++) {

                    if(res.characteristics[i].uuid.indexOf("fec8")>-1)
                    {
                        that.setData({
                            characteristicId: res.characteristics[i].uuid,
                            serviceId: e.currentTarget.id
                        })
                        wx.notifyBLECharacteristicValueChanged({
                            state: true, // 启用 notify 功能
                            // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
                            deviceId: that.data.connectedDeviceId,
                            // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
                            serviceId: that.data.serviceId,
                            // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
                            characteristicId: that.data.characteristicId,
                            complete: function (res) {
                                console.log('notifyBLECharacteristicValueChanged success', res.errMsg,that.data.characteristicId)
                                
                            }
                        })
                    }
                    else if(res.characteristics[i].uuid.indexOf("fec7")>-1)
                    {
                            that.setData({
                            writeCharacteristicId: res.characteristics[i].uuid,
                            writeServiceId: e.currentTarget.id
                            })
                    }
                }
                

            }
        })
    },
    recieveequ: function (e) {
        var that = this
        wx.readBLECharacteristicValue({
            // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
            deviceId: that.data.connectedDeviceId,
            // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
            serviceId: that.data.serviceId,
            characteristicId: that.data.characteristicId,
            success: function (res) {
                console.log('readBLECharacteristicValue:')
                console.log(res)
            }
        })
    },
    test:function(){
        var that = this
        wx.notifyBLECharacteristicValueChanged({
                            state: true, // 启用 notify 功能
                            // 这里的 deviceId 需要在上面的 getBluetoothDevices 或 onBluetoothDeviceFound 接口中获取
                            deviceId: that.data.connectedDeviceId,
                            // 这里的 serviceId 需要在上面的 getBLEDeviceServices 接口中获取
                            serviceId: "0000ffe7-0000-1000-8000-00805f9b34fb",
                            // 这里的 characteristicId 需要在上面的 getBLEDeviceCharacteristics 接口中获取
                            characteristicId: "0000fec8-0000-1000-8000-00805f9b34fb",
                            complete: function (res) {
                                console.log('notifyBLECharacteristicValueChanged complete', res.errMsg)
                            }
                        })
    }
})

function str2Bytes(str)
{
	var pos = 0;
	var len = str.length;
	if (len % 2 != 0)
		{
		return null;
	}
	len /= 2;
	var hexA = new Array();
	for (var i = 0; i < len; i++)
		{
		var s = str.substr(pos, 2);
		var v = parseInt(s, 16);
		hexA.push(v);
		pos += 2;
	}
	return hexA;
}

//字节数组转十六进制字符串
function uint8Array2Str(buffer)
{
	var str = "";
    let dataView = new DataView(buffer)
    for (let i = 0; i < dataView.byteLength; i++) {
        var tmp = dataView.getUint8(i).toString(16)
		if (tmp.length == 1)
		{
			tmp = "0" + tmp
		}
		str += tmp
    }
	return str;
}

function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}
