//app.js
var event = require('lib/event.js');
var BLEManage = require('lib/BLEManage.js')

App({
  onLaunch: function () {
    console.log('appLoad')

    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    event(this);

    var that = this
    
    that.getSystemInfo()
    that.globalData.bleManage = new BLEManage(null)
    that.globalData.bleManage.initBLESetting()

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },

  getSystemInfo: function () {
    var that = this

    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        that.globalData.isIphone = (res.brand == 'iPhone' || res.platform == 'ios')
        if (res.brand == 'devtools') {
          that.globalData.isIphone = true
        }
        that.getLocalStore()
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },

  getLocalStore: function () {
    var  that = this
    
    wx.getStorage({
      key: 'kuserID',
      success: function (res) {
        console.log('kuserID = ' + res)
        console.log(res)
        if (res.data == undefined) {
          // that.changeHomePage()
        } else {
          that.globalData.userID = res.data
        }
      },
      fail: function (res) {
        console.log('获取用户ID失败')
        that.changeHomePage()
      }
    })
  },

  changeHomePage: function () {
    var that = this
    
    if (that.globalData.isIphone) {
      wx.reLaunch({
        url: 'pages/Login/Login',
      })
    } else {
      wx.reLaunch({
        url: '../Login/Login',
      })
    }
  },

  getUserInfo: function (cb) {
    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.getUserInfo({
        withCredentials: false,
        success: function (res) {
          that.globalData.userInfo = res.userInfo
          typeof cb == "function" && cb(that.globalData.userInfo)
        }
      })
    }
  },

  globalData: {
    userInfo: null,
    userID: null,
    bleManage: null,
    needRefresh: false,
    successCode: "111111",
  }
})

function Log(val) {
  console.log(val)
}