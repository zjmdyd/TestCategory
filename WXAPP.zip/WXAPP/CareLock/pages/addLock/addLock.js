// pages/addLock/addLock.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    
  },

  linkToaddLockTwo: function () {
    //允许从相机和相册扫码
    wx.scanCode({
      success: (res) => {
        console.log(res)
        var doorindex = res.result.indexOf("door=");
        var doorCode = res.result.substring(doorindex + 5, res.result.length);
        console.log('需添加的门锁mac = ' + doorCode)

        wx.navigateTo({
          url: '../addLockTwo/addLockTwo?mac=' + doorCode,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})