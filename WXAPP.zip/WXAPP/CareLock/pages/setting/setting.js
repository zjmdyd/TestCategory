// pages/setting/setting.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
  
  },

  linkToGateway: function () {
    wx.navigateTo({
      url: '../gateway/gateway',
    });
  },

  linkToGesture: function () {
    wx.navigateTo({
      url: '../gesture/gesture',
    });
  },

  logoutEvent:function(){
    wx.showModal({
      title: '提示',
      content: '退出后再次进入需要重新绑定手机号，是否确认退出登录?',
      confirmColor:"#1C62C3",
      cancelColor:"#666",
      success:function(res){
        if(res.confirm){
          console.log('确定')
          wx.removeStorage({
            key: 'phoneNum',
            success: function(res) {},
          })
          wx.removeStorage({
            key: 'kuserID',
            success: function(res) {
              console.log(res)
              wx.reLaunch({
                url: '../Login/Login',
              })
            },
          })
          
        }else if(res.cancel){
          console.log('取消')
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) { 
    wx.setNavigationBarTitle({
      title: '设置'
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})