// pages/addLockThree/addLockThree.js

var app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    second: 30,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    countdown(this);

    this.bleManage = app.globalData.bleManage
    this.getShakeCommand()
  },

  getShakeCommand: function () {
    var that = this

    that.bleManage.getShakeHandCommand(2, function (requstBack, msg, errorCode) {
      if (requstBack == true) {
        that.checkConnectState()

        that.bleManage.connectDevice(function (res) {
          console.log('设备绑定==>' + res)

          if (res == true) {
            that.addDevice()
          } else {
            wx.showToast({
              title: '绑定失败',
              success: function (res) {
                that.backToPageIndexDelay(2, 2)
              }
            })
          }
        }, true)
      } else {
        wx.showToast({
          title: msg,
        })

        that.backToPageIndexDelay(2, 2)
      }
    })
  },

  /*
    蓝牙连接状态检测
  */
  checkConnectState: function () {
    var that = this

    that.bleManage.checkConnectState(function (res) {
      if (res == false) {
        wx.showToast({
          title: '蓝牙已断开连接',
        })
        that.setData({
          connected: false
        })
      }
    });
  },

  addDevice: function () {
    var that = this

    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=bindDevice',
      data: {
        mac: that.bleManage.matchMac,
        user_id: app.globalData.userID,
        device_name: that.bleManage.deviceName,
      },
      success: function (res) {
        console.log(res)
        that.bindSuccess = res.data.type
        if (res.data.type == false) {
          wx.showToast({
            title: res.data.msg,
            success: function (res) {
              console.log(res)
              that.backToPageIndexDelay(2, 2)
            },
            fail: function (res) {
              console.log(res)
            }
          })
        } else {
          console.log('添加门锁成功')
        }
      },
      fail: function (res) {
        console.log('添加门锁失败')
        console.log(res)
      }
    })
  },

  backToPageIndexDelay: function (index, delay) {
    setTimeout(function () {
      wx.navigateBack({
        delta: index
      })
    }, delay*1000)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

function countdown(that) {
  console.log('countdown被调用')

  var second = that.data.second
  if (second == 0) {
    // console.log("Time Out...");
    that.setData({
      second: "Time Out..."
    });

    return;
  }
  var time = setTimeout(function () {
    that.setData({
      second: second - 1
    });
    if (that.bindSuccess) {
      wx.navigateTo({
        url: '../addLockFour/addLockFour',
      })
    } else {
      countdown(that);
    }
  }
    , 1000)
}