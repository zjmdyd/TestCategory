// pages/addLockUser/addLockUser.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentDevice: null,
    user: null,
    values: ['', '', ''],
    placeholds: ['姓名', '关系', '电话号码'],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pages = getCurrentPages()
    var prevPage = pages[pages.length - 2]
    this.prePage = prevPage

    this.setData({
      currentDevice: prevPage.data.currentDevice,
    })
  },

  inputValueChange: function (res) {
    var index = res.currentTarget.dataset.index
    var value = res.detail.value
    var newValues = this.data.values
    newValues[index] = value
    this.setData({
      values: newValues
    })
  },

  saveInfo: function () {
    var that = this
    wx.showLoading({
      title: '正在保存...',
    })
    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=addDeviceUser',
      data: {
        user_id: app.globalData.userID,
        b_id: that.data.currentDevice.b_id,
        u_name: that.data.values[0],
        r_name: that.data.values[1],
        mobile: that.data.values[2],
      },
      success: function (res) {
        console.log(res)

        if (res.data.type == true) {
          console.log('保存成功')
          that.prePage.setData({
            needRefresh: true
          })
          wx.hideLoading()
          wx.navigateBack(1)
        }else {
          wx.showToast({
            title: res.data.msg,
          })
        }
      },
      fail: function (res) {
        console.log('保存失败')
        console.log(res)
        wx.showToast({
          title: res.data.msg,
        })
              }
    })
  }
})