// pages/forgetPassword/forgetPassword.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    motto: 'Hello World',
    bingPhoneData: {
      phoneNum: '',
      code: '',
      codeIsGetting: '',
      getCodeBtnTxt: '获取验证码',
      cleanBtn: 'none',
      password: ''
    },
    userInfo: {},
    mToast: {
      animationData: {},
      text: '提示',
      display: 'none',
      opacity: 0,
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    // 调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      //更新数据
      that.setData({
        userInfo: userInfo
      })
    });
  },


  //自定义 toast 弹框
  showMToast: function (text, duration) {
    var that = this;
    var mtoast = that.data.mToast;
    if (mtoast.display == 'none') {
      mtoast.display = 'block';
      mtoast.opacity = 1;
      mtoast.text = text;
      that.setData({
        mToast: mtoast
      });
      setTimeout(function () {
        mtoast.opacity = 0;
        that.setData({
          mToast: mtoast
        });
        setTimeout(function () {
          mtoast.display = 'none';
          that.setData({
            mToast: mtoast
          });
        }, 300);
      }, duration);
    }
  },

  //手机号输入监听
  phoneInputEvent: function (e) {
    var bingPhoneData = this.data.bingPhoneData;
    bingPhoneData.phoneNum = e.detail.value;
    if (e.detail.value != '') {
      bingPhoneData.cleanBtn = 'block';
    } else {
      bingPhoneData.cleanBtn = 'none';
    }
    this.setData({
      bingPhoneData: bingPhoneData
    });
  },

  //验证码输入  
  codeInputEvent: function (e) {
    var phoneData = this.data.bingPhoneData;
    phoneData.code = e.detail.value;
    this.setData({
      bingPhoneData: phoneData
    });
  },

  // 密码输入
  passwordInputEvent: function (e) {
    var phoneData = this.data.bingPhoneData;
    phoneData.password = e.detail.value;
    this.setData({
      bingPhoneData: phoneData
    });
  },

  //清除手机号码
  cleanPhoneNum: function () {
    var data = this.data;
    var bingPhoneData = data.bingPhoneData;
    bingPhoneData.phoneNum = '';
    bingPhoneData.code = '';
    bingPhoneData.cleanBtn = 'none';
    this.setData({
      bingPhoneData: bingPhoneData
    });
  },

  //获取验证码  处理函数
  getCode: function (e) {
    var that = this;
    var data = that.data;
    var bingPhoneData = data.bingPhoneData;
    var isPhone = /^1(3|4|5|7|8)\d{9}$/;
    if (!isPhone.test(bingPhoneData.phoneNum)) {
      that.showMToast('请输入正确的手机号码', 2000);
    } else if (bingPhoneData.codeIsGetting == '') {
      that.countDown()
      that.getsecurityCode(bingPhoneData.phoneNum)  // 获取验证码      
    }
  },

  /*
    倒计时
  */
  countDown: function () {
    var that = this;
    var data = that.data;
    var interval = null;
    var time = 60;

    that.interval = setInterval(function () {
      var phoneNum = data.bingPhoneData;
      phoneNum.codeIsGetting = 'disabled';

      if (time > 0) {
        time--;
        phoneNum.getCodeBtnTxt = '重新获取(' + time + 's)'
      } else {
        phoneNum.getCodeBtnTxt = '重新获取';
        phoneNum.codeIsGetting = '';
        time = 60;
        clearInterval(that.interval);
      }

      that.setData({
        bingPhoneData: phoneNum
      });
    }, 1000)
  },

  /*
    获取验证码
  */
  getsecurityCode: function (e) {
    console.log('phone = ' + e)
    var that = this

    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=getVerify',
      data: {
        mobile: e
      },
      success: function (res) {
        console.log(res)
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },

  /*
    注册检查
  */
  registerEvent: function () {
    var that = this;
    var phoneData = that.data.bingPhoneData;
    var phoneNum = phoneData.phoneNum;
    var code = phoneData.code;
    var password = phoneData.password;
    if (phoneNum != '' && code != '' && password != '') {
      that.verifyCode()
    } else {
      var text = '';
      if (phoneNum == '') {
        text = '请输入正确的手机号码';
      } else {
        text = '请输入验证码'
      }
      that.showMToast(text, 2000);
    }
  },

  /*
    校验验证码
  */
  verifyCode: function () {
    wx.showLoading({
      title: '请稍后...',
    })
    var that = this
    var bingPhoneData = that.data.bingPhoneData;

    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=checkVerify',
      data: {
        mobile: bingPhoneData.phoneNum,
        verify: bingPhoneData.code,
      },
      success: function (res) {
        console.log(res)
        if (res.data.type == true) {
          that.register()
        } else {
          wx.hideLoading()
          that.showMToast(res.data.msg, 2000);
        }
      },
      fail: function (res) {
        console.log(res)
        wx.hideLoading()
        that.showMToast(res.data.msg, 2000);
      }
    })
  },

  /*
    重置密码
  */
  resetPasswordEvent: function () {
    var that = this
    var bingPhoneData = that.data.bingPhoneData;

    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=forgetPassword',
      data: {
        mobile: bingPhoneData.phoneNum,
        verify: bingPhoneData.code,
        password: bingPhoneData.password,
      },
      success: function (res) {
        clearInterval(that.interval)
        console.log(res)
        console.log(res.data)

        if (res.data.type == true) {
          console.log('修改密码成功')
          wx.hideLoading()
          //绑定手机
          wx.navigateBack(1)
        } else {
          wx.showToast({
            title: res.data.msg,
          })
        }
      },
      fail: function (res) {
        console.log(res)
        that.showMToast(res.data.msg, 2000);
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})