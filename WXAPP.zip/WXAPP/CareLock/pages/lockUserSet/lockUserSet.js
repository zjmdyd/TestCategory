// pages/lockUserSet/lockUserSet.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    user: null,
    values: [],
    placeholds: ['姓名', '关系', '电话号码'],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pages = getCurrentPages()
    var prevPage = pages[pages.length - 2]
    this.user = prevPage.data.selectUser
    this.prePage = prevPage
    this.setData({
      values: [this.user.u_name, this.user.r_name, this.user.mobile]
    })
  },

  inputValueChange: function (res) {
    var index = res.currentTarget.dataset.index
    var value = res.detail.value
    var newValues = this.data.values
    newValues[index] = value
    this.setData({
      values: newValues
    })
  },

  saveInfo: function () {
    var that = this
    wx.showLoading({
      title: '正在保存...',
    })
    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=updateDeviceUser',
      data: {
        user_id: app.globalData.userID,
        u_b_id: that.user.u_b_id,
        u_name: that.data.values[0],
        r_name: that.data.values[1],
        mobile: that.data.values[2],
      },
      success: function (res) {
        console.log(res)

        if (res.data.type == true) {
          console.log('保存成功')
          that.prePage.setData({
            needRefresh: true
          })
          wx.hideLoading()
          wx.navigateBack(1)
        }else {
          wx.showToast({
            title: res.data.msg,
          })
        }
      },
      fail: function (res) {
        console.log(res)
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },

  deleteInfo: function () {
    var that = this

    wx.showModal({
      title: '提示',
      content: '确定删除该用户？',
      confirmText: '确定',
      confirmColor: '#154992',
      cancelColor: "#999",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          that.deleteUser()
        }
      }
    })
  },

  deleteUser: function () {
    var that = this
    wx.showLoading({
      title: '正在删除...',
    })
    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=delBindUser',
      data: {
        user_id: app.globalData.userID,
        u_b_id: that.user.u_b_id,
      },
      success: function (res) {
        console.log(res)

        if (res.data.type == true) {
          console.log('保存成功')
          that.prePage.setData({
            needRefresh: true
          })
          wx.hideLoading()
          wx.navigateBack(1)
        } else {
          wx.showToast({
            title: res.data.msg,
          })
        }
      },
      fail: function (res) {
        console.log(res)
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})