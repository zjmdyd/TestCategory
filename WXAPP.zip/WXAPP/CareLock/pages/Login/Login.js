//Login.js
//获取应用实例
var app = getApp()

Page({
  data: {
    motto: 'Hello World',
    bingPhoneData: {
      phoneNum: '',
      password: '',
      cleanBtn: 'none'
    },
    userInfo: {},
    mToast: {
      animationData: {},
      text: '提示',
      display: 'none',
      opacity: 0,
    }
  },

  //自定义 toast 弹框
  showMToast: function (text, duration) {
    var that = this;
    var mtoast = that.data.mToast;
    if (mtoast.display == 'none') {
      mtoast.display = 'block';
      mtoast.opacity = 1;
      mtoast.text = text;
      that.setData({
        mToast: mtoast
      });
      setTimeout(function () {
        mtoast.opacity = 0;
        that.setData({
          mToast: mtoast
        });
        setTimeout(function () {
          mtoast.display = 'none';
          that.setData({
            mToast: mtoast
          });
        }, 300);
      }, duration);
    }
  },

  //手机号输入监听
  phoneInputEvent: function (e) {
    var bingPhoneData = this.data.bingPhoneData;
    bingPhoneData.phoneNum = e.detail.value;
    if (e.detail.value != '') {
      bingPhoneData.cleanBtn = 'block';
    } else {
      bingPhoneData.cleanBtn = 'none';
    }
    this.setData({
      bingPhoneData: bingPhoneData
    });
  },

  //密码输入  
  passwordInputEvent: function (e) {
    var phoneNum = this.data.bingPhoneData;
    phoneNum.password = e.detail.value;
    this.setData({
      bingPhoneData: phoneNum
    });
  },

  //清除手机号码
  cleanPhoneNum: function () {
    var data = this.data;
    var bingPhoneData = data.bingPhoneData;
    bingPhoneData.phoneNum = '';
    bingPhoneData.code = '';
    bingPhoneData.cleanBtn = 'none';
    this.setData({
      bingPhoneData: bingPhoneData
    });
  },

  /*
    登录检查
  */
  loginEvent: function () {
    var that = this;
    var phoneData = that.data.bingPhoneData;
    var phoneNum = phoneData.phoneNum;
    var passowrd = phoneData.passowrd;
    if (phoneNum != '' && passowrd != '') {
      that.login()
    } else {
      var text = '';
      if (phoneNum == '') {
        text = '请输入正确的手机号码';
      } else {
        text = '请输入密码'
      }
      that.showMToast(text, 2000);
    }
  },

  /*
  登录
  */
  login: function () {
    wx.showLoading({
      title: '请稍后...',
    })
    var that = this
    var bingPhoneData = that.data.bingPhoneData;

    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=login',
      data: {
        mobile: bingPhoneData.phoneNum,
        password: bingPhoneData.password,
      },
      success: function (res) {
        clearInterval(that.interval)
        console.log(res)
        console.log(res.data)

        if(res.data.type == true) {
          console.log('登录成功')
          wx.hideLoading()
          wx.setStorage({
            key: 'kuserID',
            data: res.data.user_id
          })
          wx.setStorage({
            key: 'phoneNum',
            data: bingPhoneData.phoneNum,
          })
          app.globalData.userID = res.data.user_id

          //绑定手机
          wx.reLaunch({
            url: '../index/index',
          });
        }else {
          wx.showToast({
            title: '登录出错,服务器故障'
          })
        }        
      },
      fail: function (res) {
        console.log(res)
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },

  registerEvent: function () {
    wx.navigateTo({
      url: '../register/register',
    })
  },

  // 测试相机
  showCamera: function () {
    wx.navigateTo({
      url: '../testPhoto/testPhoto',
    })
  },

  passwordEvent: function () {
    wx.navigateTo({
      url: '../forgetPassword/forgetPassword',
    })
  },

  onLoad: function () {
    console.log('log onLoad')

    var that = this
    // 调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      //更新数据
      that.setData({
        userInfo: userInfo
      })      
    });

    wx.getStorage({
      key: 'phoneNum',
      success: function(res) {
        console.log(res)

        var bingPhoneData = that.data.bingPhoneData;
        bingPhoneData.phoneNum = res.data;
        that.setData({
          bingPhoneData: bingPhoneData
        });
      },
    })
  }
})
