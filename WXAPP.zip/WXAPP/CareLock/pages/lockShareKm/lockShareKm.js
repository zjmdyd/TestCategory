// pages/lockShareKm/lockShareKm.js
var app = getApp()
var util = require('../../utils/util.js')

Page({
  /**
   * 页面的初始数据
   */
  data: {
    connected: false,
    validTime: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    console.log('options ==>')
    console.log(options)
    this.shareOpenKey = options.key
    this.currentMac = options.mac
    
    let timeStamp = options.time
    var date = new Date()
    date.setTime(timeStamp)
    this.setData({
      validTime: util.formatTime(date)
    })

    this.bleManage = app.globalData.bleManage
    this.bleManage.isShare = true
    app.globalData.bleManage.globalData = app.globalData
    this.searchCurrentDevice()
  },

  searchCurrentDevice: function () {
    var that = this

    if (that.bleManage.openAdapter == false) {
      // console.log(that.bleManage)
      // console.log(that.bleManage.openAdapter)
      wx.showToast({
        title: '请打开手机蓝牙',
      })

      that.interval = setInterval(function () {
        console.log('检查手机蓝牙aa', that.bleManage.openAdapter)
        if (that.bleManage.openAdapter == true) {
          that.searchCurrentDevice()
          clearInterval(that.interval)
        }
      }, 1500)

      return
    }

    that.searchEvent()
  },

  searchEvent: function () {
    var that = this
    var time = 30

    that.searchInterval = setInterval(function () {
      console.log('搜索设备', time)
      that.bleManage.searchDevice(function (res) {
        if (res == true) {
          that.connectCurrentDevice()
          clearInterval(that.searchInterval)
        } else {
          if (time > 0) {
            time--
            wx.showLoading({
              title: '正在搜索设备...',
            })
          } else {
            wx.hideLoading()
            wx.showToast({
              title: '未搜索到设备,请重新打开蓝牙',
            })
            clearInterval(that.searchInterval)
          }
        }
      }, that.currentMac)
    }, 1000)
  },
  
  connectCurrentDevice: function () {
    var that = this

    wx.showLoading({
      title: '正在连接设备...',
    })
    that.bleManage.getShareShakeCommand(that.shareOpenKey, function (requestBack, msg, errorCode) {
      if (requestBack == true) {
        that.checkConnectState()
        that.bleManage.connectDevice(function (res) {
          if (res == false) {
            wx.showToast({
              title: '连接设备失败',
            })
          }
          that.setData({
            connected: res
          })
        }, false)
      } else {
        wx.showToast({
          title: msg,
        })

        setTimeout(function () {
          wx.navigateBack({
            delta: 2
          })
        }, 2000)
      }
    })
  },

  /*
    蓝牙连接状态检测
  */
  checkConnectState: function () {
    var that = this

    that.bleManage.listenConnectState(function (res) {
      if (res == false) {
        wx.showToast({
          title: '蓝牙已断开连接',
        })
        that.setData({
          connected: false
        })
      }
    });
  },

  openDoor: function () {
    var that = this

    if (that.data.connected == true) {
      that.bleManage.openDoor()
    } else {
      that.searchCurrentDevice()
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('分享onShow')
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearInterval(this.interval)
    clearInterval(this.searchInterval)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})