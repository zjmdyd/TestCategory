// pages/addMember/addMember.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    previewPortrait:'../../images/bg_touxiang_512x512.png',
    currentDevice: null,
    placeholds: ['门锁名称', '紧急联系人', '紧急电话号码'],
    values: [],
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pages = getCurrentPages()
    var prevPage = pages[pages.length - 2]

    var device = prevPage.data.currentDevice
    this.setData({
      currentDevice: device,
      values: [device.set_name, device.contact_name, device.contact_mobile]
    })
  },

  inputValueChange: function (res) {
    var index = res.currentTarget.dataset.index
    var value = res.detail.value
    var newValues = this.data.values
    newValues[index] = value
    this.setData({
      values: newValues
    })
  },

  saveInfo: function () {
    var that = this
    wx.showLoading({
      title: '正在保存...',
    })
    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=setDeviceName',
      data: {
        user_id: app.globalData.userID,
        mac: that.data.currentDevice.mac,
        set_name: that.data.values[0],
        contact_name: that.data.values[1],
        contact_mobile: that.data.values[2],
      },
      success: function (res) {
        console.log(res)

        if (res.data.type == true) {
          console.log('保存成功')
          app.globalData.needRefresh = true

          wx.hideLoading()
          wx.navigateBack(1)
        } else {
          wx.showToast({
            title: res.data.msg,
          })
        }
      },
      fail: function (res) {
        console.log(res)
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },

  selectPortrait: function () {
    var that = this;
    wx.chooseImage({
      count: 1,
      success: function (res) {
        console.log(res.tempFilePaths);
        that.setData({
          previewPortrait: res.tempFilePaths[0]
        })
      },
    })
  }
})