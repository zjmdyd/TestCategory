// pages/lockUser/lockUser.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentDevice: null,
    userList: [],
    selectUser: null,
    needRefresh: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pages = getCurrentPages()
    var prevPage = pages[pages.length - 2]

    this.setData({
      currentDevice: prevPage.data.currentDevice,
    })
  },

  getUsers: function () {
    var that = this
    wx.showLoading({
      title: '正在获取门锁列表',
    })
    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=getMineUserList',
      data: {
        user_id: app.globalData.userID,
        b_id: that.data.currentDevice.b_id
      },
      success: function (res) {
        console.log(res)

        if (res.data.type == true) {
          console.log('获取门锁用户成功')
          that.setData({
            userList: res.data.dataArray
          })
          wx.hideLoading()
        }else {
          wx.showToast({
            title: res.data.msg,
          })
        }
        
      },
      fail: function (res) {
        console.log('获取门锁用户失败')
        console.log(res)
        wx.showToast({
          title: res.data.msg,
        })
      }
    })
  },

  setUserInfo: function (e) {
    this.setData({
      selectUser: e.currentTarget.dataset.item
    })
    wx.navigateTo({
      url: '../lockUserSet/lockUserSet',
    })
  },

  /*
    添加门锁用户
  */
  addLockUser: function () {
    wx.navigateTo({
      url: '../addLockUser/addLockUser',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (this.data.needRefresh) {
      this.getUsers()
      this.setData({
        needRefresh: false
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})