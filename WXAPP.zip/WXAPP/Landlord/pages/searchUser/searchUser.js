// pages/searchUser/searchUser.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    users: [],
    searchKey: '',
    hiddenCancel: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  searchUsers: function (e) {
    console.log(e)
    var that = this
    let text = e.detail.value
    if (text == that.data.searchKey) return

    that.setData({
      searchKey: text,
    })

    if(text.length == 0) {
      that.setData({
        users: [],
      })
      return
    }

    wx.request({
      header: {
        token: app.globalData.token
      },
      url: app.globalData.kDomain + '/api/landlord/householder/list',
      data: {
        page: 1,
        limit: 20,
        key: text,
      },
      success: function (res) {
        console.log(res)

        if (res.statusCode == 200) {
          that.setData({
            users: res.data.page.list,
          })
        } else {
          wx.showToast({
            title: res.data.errMsg,
          })
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },

  becomeFirstRespond: function (e) {
    console.log(e)
    this.setData({
      hiddenCancel: false
    })
  },

  resignFirstRespond: function (e) {
    this.setData({
      hiddenCancel: true
    })
  },

  cancelSearch: function () {
    setTimeout(function() {
      wx.navigateBack(1)
    }, 500)

    // var that = this
    // if (that.data.searchKey.length) {

    // }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})