// pages/banUserInfo/banUserInfo.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    zhuhuarray: ['租客', '业主', '家人', '代理人', '临时客人'],
    guanaiarray: ['普通', '残疾人士', '孤寡老人', '老上访户', '老干部', '留守儿童', '五保户', '其他'],
    waijiarray: ['否', '是'],
    luruarray: ['拍照上传', '手工录入'],
    xingbiearray: ['男', '女'],
  },

  authorizeAPP: function () {
    wx.navigateTo({
      url: '../authorizeAPP/authorizeAPP',
    })
  },

  showUserCards: function () {
    wx.navigateTo({
      url: '../userCards/userCards',
    })
  },
  
  Changezhuhu: function (e) {
    console.log('选择类型', e.detail.value)
    this.setData({
      zhuhu: e.detail.value
    })
  },
  Changeguanai: function (e) {
    console.log('选择类型', e.detail.value)
    this.setData({
      guanai: e.detail.value
    })
  },
  Changewaiji: function (e) {
    console.log('选择类型', e.detail.value)
    this.setData({
      waiji: e.detail.value
    })
  },
  Changeluru: function (e) {
    console.log('选择类型', e.detail.value)
    this.setData({
      luru: e.detail.value
    })
  },
  Changexingbie: function (e) {
    console.log('选择类型', e.detail.value)
    this.setData({
      xingbie: e.detail.value
    })
  },
  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      date: e.detail.value
    })
  },

  topimgup: function () {
    wx.chooseImage({
      count: 1, // 默认9
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
        var tempFilePaths = res.tempFilePaths
      }
    })
  },

})