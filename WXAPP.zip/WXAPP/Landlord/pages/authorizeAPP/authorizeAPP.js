// pages/banUserInfoApp/banUserInfoApp.js
var app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    types: ['授权', '不授权'],
    type: -1,
  },

  Changeapp: function (e) {
    console.log('选择类型', e.detail.value)
    this.setData({
      type: e.detail.value
    })
  },

  DateChangesStart: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      startdate: e.detail.value
    })
  },

  DateChangesEnd: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      enddate: e.detail.value
    })
  },
})