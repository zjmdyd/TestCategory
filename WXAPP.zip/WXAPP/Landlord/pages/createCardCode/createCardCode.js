// pages/banUserInfoCardCode/banUserInfoCardCode.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 授权卡有效期默认12小时
    startdate: '2017-12-12',
    starttime: '18:21',
    // 授权卡有效期默认1年
    enddate: '2017-12-12',
    hiddenDetailView: true,
    animationData: {},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  showCodeDetail: function () {
    this.setData({
      hiddenDetailView: false,
    })

    this.animation(-603)
  },

  didmissDetail: function () {
    this.animation(603)
  },

  /**
   * 生命周期函数--监听页面显示
   */

  animation: function (e) {
    var animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease',
    })

    setTimeout(function () {
      animation.translateY(e).step()
      this.setData({
        animationData: animation.export(),
      })

      if (e > 0) {
        this.setData({
          hiddenDetailView: true,
        })
      }
    }.bind(this), 250)
  },

  DateChangesStart: function (e) {
    this.setData({
      startdate: e.detail.value
    })
  },

  TimeChangesStart: function (e) {
    this.setData({
      starttime: e.detail.value
    })
  },

  DateChangesEnd: function (e) {
    this.setData({
      enddate: e.detail.value
    })
  },

  /**
    * 生命周期函数--监听页面初次渲染完成
    */
  onReady: function () {

  },

  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})