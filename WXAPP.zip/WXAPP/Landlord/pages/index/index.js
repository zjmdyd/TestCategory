//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    houses: [],   // 楼栋
    currentIndex: 0,
    currentHouse: null,
    roomList: [], // 某楼栋的房间
  },

  onLoad() {
    var that = this

    wx.getStorage({
      key: 'houseIndex',
      success: function (res) {
        console.log(res)
        that.setData({
          currentIndex: res.data
        })
        that.requestData()
      },
      fail: function (res) {
        that.requestData()
      }
    })
  },

  requestData: function () {
    var that = this

    wx.request({
      header: {
        token: app.globalData.token
      },
      url: app.globalData.kDomain + '/api/landlord/building/list',
      data: {
        page: 1,
        limit: 20,
      },
      success: function (res) {
        console.log(res)

        if (res.statusCode == 200) {
          if (res.data.code == 500) {
            wx.showToast({
              title: res.data.msg,
            })
            setTimeout(function () {
              that.changeHomePage()
            }, 1500)
          } else {
            that.setData({
              houses: res.data.page.list,
              currentHouse: res.data.page.list[that.data.currentIndex],
            })
            that.requestRoomList();
          }
        } else {
          wx.showToast({
            title: res.data.errMsg,
          })
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },

  requestRoomList: function () {
    var that = this

    wx.request({
      header: {
        token: app.globalData.token,
        buildingId: that.data.currentHouse.buildingId,
      },
      url: app.globalData.kDomain + '/api/landlord/room/list',
      data: {
        page: 1,
        limit: 20,
      },
      success: function (res) {
        console.log(res)

        if (res.statusCode == 200) {
          if(res.data.code == 500) {
            wx.showToast({
              title: res.data.msg,
            })
            setTimeout(function () {
              that.changeHomePage()
            }, 1500)
          }else {
            that.setData({
              roomList: res.data.page.list,
            })
          }
        } else {
          wx.showToast({
            title: res.data.errMsg,
          })
        }
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },

  changeHomePage: function () {
    if (app.globalData.isIphone) {
      wx.reLaunch({
        url: '../login/login',
      })
    } else {
      wx.reLaunch({
        url: '../login/login',
      })
    }
  },

  //事件处理函数
  linkTobanReplace: function () {
    wx.navigateTo({
      url: '../banReplace/banReplace'
    })
  },

  showRoomUsers: function (e) {
    let index = e.currentTarget.dataset.index
    let room = this.data.roomList[index]

    wx.navigateTo({
      url: '../roomUsers/roomUsers?roomId=' + room.roomId,
    })
  },

  searchUser: function () {
    wx.navigateTo({
      url: '../searchUser/searchUser',
    })
  },

  openDoorLogs: function () {
    wx.navigateTo({
      url: '../openDoorLogs/openDoorLogs',
    })
  },

  onShow: function () {
    var that = this

    if(that.needRefresh == true) {
      this.requestRoomList()
      that.needRefresh = false
    }
  }
})
