//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    this.getSystemInfo()

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              // 可以将 res 发送给后台解码出 unionId
              this.globalData.userInfo = res.userInfo

              // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
              // 所以此处加入 callback 以防止这种情况
              if (this.userInfoReadyCallback) {
                this.userInfoReadyCallback(res)
              }
            }
          })
        }
      }
    })
  },

  getSystemInfo: function () {
    var that = this

    wx.getSystemInfo({
      success: function (res) {
        console.log(res)
        that.globalData.isIphone = (res.brand == 'iPhone' || res.model.indexOf('iPhone') > -1)
        that.getLocalStore()
      },
      fail: function (res) {
        console.log(res)
      }
    })
  },

  getLocalStore: function () {
    var that = this

    wx.getStorage({
      key: 'token',
      success: function (res) {
        console.log('token = ' + res)
        console.log(res)
        if (res.data == undefined) {
          that.changeHomePage()
        } else {
          that.globalData.token = res.data
        }
      },
      fail: function (res) {
        console.log('获取token失败')
        that.changeHomePage()
      }
    })
  },

  changeHomePage: function () {
    if (this.globalData.isIphone) {
      wx.reLaunch({
        url: 'pages/login/login',
      })
    } else {
      wx.reLaunch({
        url: 'pages/login/login',
      })
    }
  },

  globalData: {
    userInfo: null,
    userID: null,
    kDomain: 'http://119.145.33.202:8334/renren-fastplus'
  }
})