// pages/memberManage/memberManage.js
var app = getApp()

Page({
  /**
   * 页面的初始数据
   */
  data: {
    currentDevice: null,
    connected: false,
    cellTitles: ['远程开门', '门锁用户列表', '日志', '门锁设置', '门锁解绑'],
    pagesNames: ['lockShare', 'lockUser', 'lockHistory', 'lockSetting'],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var pages = getCurrentPages()
    var prevPage = pages[pages.length - 2]

    this.setData({
      currentDevice: prevPage.data.currentDevice,
    })
    console.log(this.data.currentDevice)

    this.bleManage = app.globalData.bleManage
    this.searchCurrentDevice()

    if (this.data.currentDevice.type != 0) {
      this.setData({
        cellTitles: ['远程开门', '日志', '门锁解绑'],
        pagesNames: ['lockShare', 'lockHistory',],
      })
    }
    var name = this.data.currentDevice.set_name
    if(name.length == 0) {
      name = this.data.currentDevice.device_name
    }

    wx.setNavigationBarTitle({
      title: name,
    })
  },

  searchCurrentDevice: function () {
    var that = this

    if (that.bleManage.openAdapter != true) {
      wx.showToast({
        title: '请打开手机蓝牙',
      })

      that.interval = setInterval(function () {
        console.log('检查手机蓝牙', that.bleManage.openAdapter)
        if (that.bleManage.openAdapter == true) {
          that.searchCurrentDevice()
          clearInterval(that.interval)
        }
      }, 1500)

      return
    }

    that.getShakeCommand()
  },

  getShakeCommand: function () {
    var that = this

    wx.showLoading({
      title: '正在搜索设备...',
    })

    that.bleManage.matchMac = that.data.currentDevice.mac
    that.bleManage.getShakeHandCommand(1, function (requestBack, msg, errorCode) {
      if (requestBack == true) {
        that.searchEvent()
      } else {
        wx.showToast({
          title: msg,
        })
        if (errorCode == '12138') {
          app.globalData.needRefresh = true // 有删除
        }

        setTimeout(function () {
          wx.navigateBack({
            delta: 2
          })
        }, 2000)
      }
    })
  },

  searchEvent: function () {
    var that = this
    var time = 30

    that.searchInterval = setInterval(function () {
      console.log('搜索设备定时器', time)
      that.bleManage.searchDevice(function (res) {
        console.log('搜索设备callback')
        console.log(res)
        if (res == true) {
          setTimeout(function () {
            that.connecEvent()
            that.checkConnectState()
          }, 2000)
          clearInterval(that.searchInterval)
        } else {
          if (time > 0) {
            time--
          } else {
            wx.hideLoading()
            wx.showToast({
              title: '未搜索到设备,请重新打开蓝牙',
            })
            clearInterval(that.searchInterval)
          }
        }
      }, that.data.currentDevice.mac)
    }, 1000)
  },

  connecEvent: function () {
    wx.showLoading({
      title: '正在连接设备',
    })
    var that = this
    that.bleManage.connectDevice(function (res) {
      if (res == false) {
        wx.showToast({
          title: '连接设备失败',
        })
      }
      that.setData({
        connected: res
      })
    }, false)
  },

  /*
    蓝牙连接状态检测
  */
  checkConnectState: function () {
    var that = this

    that.bleManage.listenConnectState(function (res) {
      if (res == false) {
        wx.showToast({
          title: '蓝牙已断开连接',
        })
        that.setData({
          connected: false
        })
      }
    });
  },

  openDoor: function () {
    var that = this

    if (that.data.connected == true) {
      that.bleManage.openDoor()

      app.globalData.needRefresh = true
    } else {
      that.searchCurrentDevice()
    }
  },

  selectCellItemAtIndex: function (e) {
    let index = e.currentTarget.dataset.item
    var that = this

    if (index == that.data.pagesNames.length) {
      that.bowOutEvent()
    } else {
      let name = that.data.pagesNames[index]
      var pagePath = '../' + name + '/' + name

      console.log(pagePath)
      wx.navigateTo({
        url: pagePath,
      });
    }
  },

  bowOutEvent: function () {
    var that = this

    wx.showModal({
      title: '提示',
      content: '解除绑定后，你关联的门锁将不会在有任何提醒，是否确认解绑？',
      confirmText: '解除绑定',
      confirmColor: '#154992',
      cancelColor: "#999",
      success: function (res) {
        console.log(res)
        if (res.confirm) {
          that.unbindDevice()
        }
      }
    })
  },

  unbindDevice: function () {
    var that = this
    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=releaseDevice',
      data: {
        mac: that.data.currentDevice.mac,
        user_id: app.globalData.userID,
      },
      success: function (res) {
        console.log(res)
        if (res.statusCode == 200) {
          console.log('解除门锁成功')
          app.globalData.needRefresh = true // 有删除
          wx.navigateBack({
            delta: 2
          })
        }
      },
      fail: function (res) {
        console.log('获取门锁列表失败')
        console.log(res)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    clearInterval(this.interval)
    clearInterval(this.searchInterval)
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})