// pages/index/index.js
//获取应用实例
var app = getApp()

const UserTypes = ['未知类型', '密码', 'M1卡', '身份证', '指纹', '蓝牙', '管理员用户']

Page({
  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    bindDevices: [],
    currentDevice: null,
    currentDoorLogs: null,  // 当前门锁的日志
    openDoorLogs: [],       // 所有门锁的日志
    hadRequestIdxs: [],
    currentIndex: 0,
    isBindHousingEstate: 'noBind',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('页面-->onLoad')
    var that = this

    // 调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      //更新数据
      that.setData({
        userInfo: userInfo
      })
      app.globalData.bleManage.globalData = app.globalData
    });

    app.globalData.needRefresh = true
  },

  /*
    获取备列表
  */
  getBindLocks: function () {
    if (app.globalData.userID == undefined) return
    
    console.log('开始请求设备列表')
    
    var that = this
    wx.showLoading({
      title: '正在获取门锁列表...',
    })

    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=getBindDeviceList',
      data: {
        user_id: app.globalData.userID,
      },
      success: function (res) {
        console.log('获取门锁列表成功')
        console.log(res)
        var array = res.data.data_array
      // 
        if (array.length) {
          that.setData({
            bindDevices: array,
            currentDevice: array[0]  // 设备列表显示的当前设备
          })
          that.getDoorLogs(that.data.currentIndex)
        }
        wx.hideLoading()
      },
      fail: function (res) {
        console.log(res)
        wx.showToast({
          title: '获取门锁列表失败',
        })
      }
    })
  },

  /*
    获取门锁日志历史
  */
  getDoorLogs: function (index) {
    console.log('*****从服务器获取日志数据******' + index)

    var that = this

    that.setData({
      currentIndex: index
    })

    if (index == that.data.bindDevices.length) return

    var hadRequest = false
    var requestedIdxs = that.data.hadRequestIdxs
    for (let i = 0; i < requestedIdxs.length; i++) {
      let idx = requestedIdxs[i]
      if (idx == index) {
        hadRequest = true
        break
      }
    }
    
    // 已请求
    if (hadRequest) {
      that.setData({
        currentDoorLogs: that.data.openDoorLogs[index],
        currentDevice: that.data.bindDevices[index]
      })
      return
    }

    // 未请求
    requestedIdxs.push(index)
    that.setData({
      hadRequestIdxs: requestedIdxs,
      currentDevice: that.data.bindDevices[index]
    })

    console.log('currentDeviceMac == ' + that.data.currentDevice.mac)

    wx.request({
      url: 'https://pms.hotel580.com/api/lock/lock.jsp?action=getLogList',
      data: {
        mac: that.data.currentDevice.mac,
      },
      success: function (res) {
        console.log(res)

        let datas = res.data.dataArray
        if (datas instanceof Array) {
          var logs = that.data.openDoorLogs
          logs.push(datas)
          that.setData({
            currentDoorLogs: datas,
            openDoorLogs: logs,
          })
        }
        wx.stopPullDownRefresh()
      },
      fail: function (res) {
        console.log(res)
        wx.showToast({
          title: '请求失败, 请检查网络设置',
        })
        wx.stopPullDownRefresh()
      }
    })
  },

  /*
    当前下标改变
  */
  currentIndexChange: function (e) {
    var that = this
    var idx = e.detail.current
    console.log('index have changed to ' + idx)

    that.getDoorLogs(idx)
  },

  /*
    门锁详情
  */
  linkToLockDetail: function () {
    wx.navigateTo({
      url: '../lock/lock',
    });
  },

  /*
    添加门锁
  */
  linkToaddLock: function () {
    wx.navigateTo({
      url: '../addLock/addLock',
    });
  },

  linkToSetting: function () {
    wx.navigateTo({
      url: '../setting/setting',
    });
  },

  loadMore: function () {
    console.log('loadMore')
  },

  onPullDownRefresh: function () {
    this.refreshData()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.log('页面-->onReady')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log('页面-->onShow')
    if (app.globalData.needRefresh) {
      this.refreshData()
    }
  },

  refreshData: function () {
    app.globalData.needRefresh = false

    var that = this

    that.setData({
      bindDevices: [],
      hadRequestIdxs: [],
      openDoorLogs: [],
      currentIndex: 0
    })
    if (app.globalData.userID) {
      that.getBindLocks()
    }else {
    setTimeout(function(){
      that.getBindLocks()
    }, 1000)
      // wx.getStorage({
      //   key: 'kuserID',
      //   success: function (res) {
      //     console.log('kuserID = ' + res)
      //     console.log(res)
      //     if (res.data != undefined) {
      //       app.globalData.userID = res.data

      //       that.getBindLocks()
      //     }
      //   },
      //   fail: function (res) {
      //     console.log('获取用户ID失败')
      //   }
      // })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log('页面-->onHide')
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log('页面-->onUnload')
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
/*
页面加载顺序:

  第一次加载:
    页面-->onLoad --> 页面-->onShow --> 页面-->onReady
  跳转:
     页面-->onHide
  回来:      
      页面-->onShow  每次出现都会执行
  页面退出:
      页面-->onUnload

*/

/*
    // if (app.globalData.bleManage.matchMac) {
    //   wx.navigateTo({
    //     url: '../lock/lock?mac=' + this.data.currentDeviceMac,
    //   });
    // } else {
    //   wx.showToast({
    //     title: '未搜索到该设备',
    //   })

    //   this.beganSearch()
    // }

    // setTimeout(function(){
    //   wx.redirectTo({
    //     url: '../addLockFour/addLockFour',
    //   })
    // }, 3000
    // )

  printItem: function (res) {
    for(let i = 0; i < res.length; i++) {
      console.log(res[i])
    }
  },

        // var devices = that.data.bindDevices
      // var idxs = that.data.hadRequestIdxs
      // var logs = that.data.openDoorLogs

      // devices.splice(that.data.currentIndex, 1)
      // idxs.splice(that.data.currentIndex, 1)
      // logs.splice(that.data.currentIndex, 1)

            // console.log('refresh-->')
      // that.printItem(that.data.bindDevices)
      // that.printItem(that.data.hadRequestIdxs)
      // that.printItem(that.data.openDoorLogs)

  */